/* ============================================================================
   FILE       2.10 PERFORMANCE VS. LEAD-IN                          (PRD 2.10)
   PURPOSE    The series' hourly block against the block that led into it.
   SOURCE     CRIS_TELECAST_FACT [S2-T0]
   VALIDATION AEN, Customer Wars. Customer Wars is a half-hour show airing two
              episodes back to back at 10p and 10:30p, which is exactly why the
              block logic exists: a telecast-level join makes the 10:30p
              episode's lead-in Customer Wars itself and silently drops it.
              Per Kristen, week 1 section 6B: average the half hours and treat
              them as an hourly block, so Customer Wars 10-11p reads against
              Road Wars 9-10p.
   [BLK1]     SERIES BLOCK = every contiguous first-run episode of the series on
              the same night, duration weighted, starting at the first episode.
   [BLK2]     LEAD-IN BLOCK = the programme adjacent to the block start, then
              its own contiguous run walked backwards.
   [LEADIN-TC] SUPERSEDES [BLK1]/[BLK2] BY DEFAULT. Jill, 28 Sep 2026, on Modern
              Marvels: WWII (3 premiere telecasts): "three lead-in telecasts
              overall - one new episode of World War II with Tom Hanks, one new
              episode of Modern Marvels, one repeat of Modern Marvels". So:
                - the unit is the PREMIERE TELECAST, not the night's block;
                - its lead-in is the ONE telecast that ends within p_adjacent_min
                  before it starts (shorts stepped over), whatever programme,
                  whatever airing - including a first run of the same series
                  when two premieres air back to back;
                - PREMIERE / REPEAT comes from that one telecast's
                  IS_FIRST_RUN_CT, not from the max over a run.
              v72-v74 walked the lead-in programme's whole run backwards and
              excluded the series' own first runs, which is why Modern Marvels
              returned 4 lead-in episodes (2 Tom Hanks repeats, 2 MM repeats)
              where Jill counts 3. p_leadin_grain = 'BLOCK' keeps the night-block unit.
   ============================================================================ */
-- ===== PARAMETERS =====
SET p_network       = 'HIST';
SET p_program       = '%SECRET SKINWALKER RANCH%';
SET p_season        = NULL;        -- NULL = most recent season for the series
SET p_stream        = 'Live+SD';
SET p_demo          = 'DEMO_AA';   -- [S2-DEMO] the network's own default. Any AA
                                   -- column the source view carries can be named
                                   -- instead: 'P25_64_AA_ESTIMATES',
                                   -- 'F25_64_AA_ESTIMATES', 'P18_49_AA_ESTIMATES',
                                   -- 'P25_AA_ESTIMATES', 'M25_54_AA_ESTIMATES'.
                                   -- The name is the column; nothing is summed.
SET p_include_specials = TRUE;
SET p_win_from      = NULL;        -- NULL = trailing 12 months to the last full Sunday
SET p_win_to        = NULL;
SET p_min_leadin_min = 15;      -- [SHORTS] Jill, 24 Sep 2026: when History Shorts
                                -- airs right before the series, the short is not
                                -- the lead-in; go back to the programme before it.
                                -- Anything shorter than this many minutes is
                                -- stepped over. NULL turns the rule off.
SET p_adjacent_min  = 5;        -- [ADJACENT] a programme leads in if it ends within
                                -- this many minutes of the block start, not only
                                -- on the exact second. Nielsen books the 8pm
                                -- Skinwalker repeat as ending 20:58 because a
                                -- two-minute short inside it is carved out, so
                                -- exact adjacency found nothing on five nights.
SET p_rollup        = FALSE;    -- [LEADIN-ROLLUP] Jill, 24 Sep 2026: not one row
                                -- per telecast. TRUE returns the season: the
                                -- series average against the average of all its
                                -- lead-ins, then one row per lead-in programme.
SET p_leadin_grain  = 'TELECAST'; -- [LEADIN-TC] 'TELECAST' = each premiere telecast
                                  -- against the one telecast right before it (Jill,
                                  -- 28 Sep 2026). 'BLOCK' = v74 behaviour: the night's
                                  -- contiguous premieres as one block against the
                                  -- lead-in programme's whole run (Kristen, week 1,
                                  -- Customer Wars). Under TELECAST a 10:30p episode
                                  -- reads against the 10:00p one, which is what Jill
                                  -- asked for on Modern Marvels.
SET p_movies        = 'EXCLUDE';  -- [MOVIES] 'EXCLUDE' | 'ONLY' | 'BOTH'
                                  -- A&E, week 10, reported as fatal: a hard
                                  -- MOVIE_IND = 0 deletes the answer to any
                                  -- question about Lifetime, because Lifetime's
                                  -- premiere slate IS movies. Excluding them is
                                  -- right for a series question and wrong for a
                                  -- movie one, which makes it a parameter rather
                                  -- than a rule.
                                  -- EXCLUDE keeps the behaviour every validated
                                  -- series case was measured under.
SET data_sun = (SELECT MAX(LATEST_FULL_SUNDAY) FROM AUDIENCE_DEV_DB.CRIS.CRIS_LATEST_DATE
                   WHERE ($p_network IS NULL OR NETWORK_CODE = $p_network)
                     AND RATING_SOURCE = $p_stream);
-- [CAP-SUN] the window can never run past the latest full Sunday with data, even when a
-- later date is passed in (A&E review, 27 Sep 2026: TO_DATE showed a date with no data yet).
SET win_to   = (SELECT LEAST(COALESCE(TO_DATE($p_win_to), $data_sun), $data_sun));
SET win_from = (SELECT COALESCE(TO_DATE($p_win_from),
                  -- [NORM12] network norms run the latest 12 months, ending on
                  -- the most recent Sunday with data. A&E, 10 Sep 2026. Season
                  -- norms stay season-based; this is only the network ones.
                  DATEADD('day', 1, DATEADD('month', -12, $win_to))));


-- [DEMOUSED] resolve p_demo to a real column name and return it with the answer.
-- DEMO_AA is a real column carrying each network's own key demo, so a query runs
-- on it and never states what it measured. Read back, "DEMO_AA" tells a consumer
-- nothing: it is P25-64 on AEN, HIST and FYI, F25-64 on LIF and LMN, P18-49 on
-- VICE. SP_3 and SP_6 both failed on that - the question asked for P25+, the
-- default answered on P25-64, and 242 came back where 438 was expected. A wrong
-- demo does not look wrong, it looks like a number.
SET demo_used = (SELECT IFF(UPPER(COALESCE($p_demo,'DEMO_AA')) = 'DEMO_AA',
                     CASE $p_network
                          WHEN 'AEN'  THEN 'P25_64_AA_ESTIMATES'
                          WHEN 'HIST' THEN 'P25_64_AA_ESTIMATES'
                          WHEN 'FYI'  THEN 'P25_64_AA_ESTIMATES'
                          WHEN 'LIF'  THEN 'F25_64_AA_ESTIMATES'
                          WHEN 'LMN'  THEN 'F25_64_AA_ESTIMATES'
                          -- VICE is a SiiRA assumption, never confirmed by A&E
                          WHEN 'VICE' THEN 'P18_49_AA_ESTIMATES'
                          ELSE 'UNRESOLVED - no default demo outside the six'
                     END,
                     UPPER($p_demo)));

WITH
fy AS (
    -- [YEARSEASON] the fiscal year each date belongs to.
    --
    -- Cable Tracks labels some programmes by calendar year rather than by
    -- season: MOVIE- ORIGINAL PREM carries CT_SEASON 2026 for everything
    -- Lifetime premiered in 2026. Partitioning a norm by that partitions it by
    -- January, so a February premiere is measured against whatever aired in the
    -- five weeks before it.
    --
    -- Where the label is a year, the season it stands for is the fiscal year.
    -- A&E's own corrected pull for the 7 February 2026 Lifetime premiere proves
    -- it: their thirteen telecasts run from 4 October to 31 January, spanning
    -- CT_SEASON 2025 and 2026, and what those thirteen share is FY26. Trailing
    -- twelve months would give 39 telecasts and a norm of 140, so the data tells
    -- the readings apart and only the fiscal year reproduces 138 and +64.5.
    --
    -- 156 programmes of 1,503 carry year labels and 3,606 telecasts of 29,291.
    -- Lifetime and LMN are 42% of them, being the movie slate, and VICE another
    -- quarter, being the dailies. A programme with a real season number is
    -- untouched, which is why the HIST cases reproduce unchanged.
    SELECT FISCAL_YEAR, FY_START, FY_END
    FROM AUDIENCE_DEV_DB.CRIS.CRIS_FY_CALENDAR
),
fact AS (
    -- [S2-SEASON] no restated CT_SEASON. f.* already carries it, and naming it
    -- again put the same column in the projection twice, so every later
    -- reference was ambiguous. It survived as the residue of
    -- `f.CT_SEASON AS SEASON_KEY`: dropping the alias left the duplicate.
    SELECT f.*, IDENTIFIER($p_demo) AS DEMO
    FROM AUDIENCE_DEV_DB.CRIS.CRIS_TELECAST_FACT f
    WHERE ($p_network IS NULL OR f.NETWORK_CODE = $p_network)
      AND f.RATING_SOURCE = $p_stream
      AND f.BROADCAST_DATE <= $win_to
      AND ( $p_movies = 'BOTH'
         OR ($p_movies = 'EXCLUDE' AND f.MOVIE_IND = 0)
         OR ($p_movies = 'ONLY'    AND f.MOVIE_IND = 1) )
      AND ($p_include_specials OR f.CONTENT_TYPE <> 'Special')
),
target AS (
    -- [S1-KEY] the series, and which of its seasons is in scope
    SELECT f2.NETWORK_CODE, f2.PROGRAM_CODE, f2.CT_SEASON,
           -- [YEARSEASON] a year label is not a season, so there the partition
           -- becomes the fiscal year the telecast falls in
           IFF(REGEXP_LIKE(f2.CT_SEASON, '^(19|20)[0-9]{2}[A-Za-z]?$'),
               'FY' || fy.FISCAL_YEAR, f2.CT_SEASON)                 AS NORM_KEY,
           REGEXP_LIKE(f2.CT_SEASON, '^(19|20)[0-9]{2}[A-Za-z]?$')   AS IS_YEAR_LABEL,
           fy.FY_START, fy.FY_END
    FROM fact f2
    LEFT JOIN fy
      ON f2.BROADCAST_DATE BETWEEN fy.FY_START AND fy.FY_END
    WHERE f2.IS_FIRST_RUN_CT
      AND ($p_program IS NULL OR f2.PROGRAM_NAME ILIKE $p_program)
      AND ($p_season  IS NULL OR f2.CT_SEASON = $p_season)
      -- [S2-SEASON] A&E, Jul-2026: a calculation that compares SEASONS may not
      -- use telecasts with no season. Not a parameter. Cable Tracks is the
      -- authority; where it has not catalogued a telecast the series does not
      -- appear in this answer rather than appearing against a guess.
      AND f2.CT_SEASON IS NOT NULL
    QUALIFY ROW_NUMBER() OVER (PARTITION BY f2.NETWORK_CODE, f2.PROGRAM_CODE
                               ORDER BY f2.BROADCAST_DATE DESC, f2.TELECAST_NUM DESC) = 1
),
series AS (
    -- [S2-SEASON] the season's premieres, scoped by
    -- the target's key so a partially tracked season is not split in two.
    SELECT f.*, t.NORM_KEY, t.IS_YEAR_LABEL
    FROM fact f
    JOIN target t
      ON  t.NETWORK_CODE = f.NETWORK_CODE
      AND t.PROGRAM_CODE = f.PROGRAM_CODE
      -- [S2-SEASON] the season, and only the season. No premiere-anchored
      -- fallback and no trailing window: a comparison whose axis is the
      -- season cannot be made against an approximation of one.
      -- [YEARSEASON] the season, unless the label is a year, in which case the
      -- season it stands for is the fiscal year. Matching on CT_SEASON there
      -- cuts the window at 1 January.
      AND ( (NOT t.IS_YEAR_LABEL AND f.CT_SEASON = t.CT_SEASON)
         OR (t.IS_YEAR_LABEL
             AND f.BROADCAST_DATE BETWEEN t.FY_START AND t.FY_END) )
    WHERE f.IS_FIRST_RUN_CT
),
night AS (
    -- every telecast on the nights the series premiered, with its start and end
    -- as minutes into the broadcast day (6:00a = 0) so midnight is not a cliff
    SELECT f.NETWORK_CODE, f.BROADCAST_DATE, f.PROGRAM_CODE, f.TELECAST_NUM,
           f.PROGRAM_NAME, f.EPISODE_NAME, f.START_TIME, f.END_TIME, f.BCAST_START_2959,
           MOD(HOUR(TO_TIME(f.START_TIME)) * 60 + MINUTE(TO_TIME(f.START_TIME)) - 360 + 1440, 1440) AS START_MIN,
           MOD(HOUR(TO_TIME(f.END_TIME))   * 60 + MINUTE(TO_TIME(f.END_TIME))   - 360 + 1440, 1440) AS END_MIN,
           f.CONTRIBUTING_DURATION, f.IS_FIRST_RUN_CT, f.DEMO
    FROM fact f
    WHERE f.BROADCAST_DATE IN (SELECT DISTINCT BROADCAST_DATE FROM series)
),
blk AS (
    -- [LEADIN-TC] TELECAST: one unit per premiere telecast.
    -- [BLK1]      BLOCK: the night's contiguous premieres of the series as one unit.
    SELECT s.NETWORK_CODE, s.BROADCAST_DATE, s.PROGRAM_CODE,
           IFF($p_leadin_grain = 'BLOCK', 0, s.TELECAST_NUM)              AS UNIT_KEY,
           MAX(s.PROGRAM_NAME)  AS PROGRAM_NAME,
           MAX(IFF($p_leadin_grain = 'BLOCK', NULL, s.EPISODE_NAME))       AS EPISODE_NAME,
           MAX(s.NORM_KEY)      AS NORM_KEY,
           COUNT(*)             AS EPISODES,
           MIN(s.START_TIME)    AS BLOCK_START,
           MAX(s.END_TIME)      AS BLOCK_END,
           MIN(MOD(HOUR(TO_TIME(s.START_TIME)) * 60 + MINUTE(TO_TIME(s.START_TIME)) - 360 + 1440, 1440)) AS BLOCK_START_MIN,
           SUM(s.DEMO * s.CONTRIBUTING_DURATION)
             / NULLIF(SUM(s.CONTRIBUTING_DURATION), 0) AS BLOCK_AA,
           SUM(s.CONTRIBUTING_DURATION) AS BLOCK_MIN
    FROM series s
    GROUP BY s.NETWORK_CODE, s.BROADCAST_DATE, s.PROGRAM_CODE, IFF($p_leadin_grain = 'BLOCK', 0, s.TELECAST_NUM)
),
shorts AS (
    -- [SHORTS] anything shorter than p_min_leadin_min is stepped over
    SELECT NETWORK_CODE, BROADCAST_DATE, START_MIN, END_MIN
    FROM night
    WHERE $p_min_leadin_min IS NOT NULL
      AND CONTRIBUTING_DURATION < $p_min_leadin_min
),
blk_adj AS (
    -- [ADJACENT] if a short sits right before the unit, the lead-in must end
    -- before the short instead
    SELECT b.NETWORK_CODE, b.BROADCAST_DATE, b.PROGRAM_CODE, b.UNIT_KEY, b.PROGRAM_NAME,
           b.EPISODE_NAME, b.NORM_KEY, b.EPISODES, b.BLOCK_START, b.BLOCK_END,
           b.BLOCK_START_MIN, b.BLOCK_AA, b.BLOCK_MIN,
           COALESCE(MIN(sh.START_MIN), b.BLOCK_START_MIN) AS ADJ_START_MIN
    FROM blk b
    LEFT JOIN shorts sh
      ON  sh.NETWORK_CODE   = b.NETWORK_CODE
      AND sh.BROADCAST_DATE = b.BROADCAST_DATE
      AND sh.END_MIN <= b.BLOCK_START_MIN
      AND b.BLOCK_START_MIN - sh.END_MIN <= COALESCE($p_adjacent_min, 0)
    GROUP BY b.NETWORK_CODE, b.BROADCAST_DATE, b.PROGRAM_CODE, b.UNIT_KEY, b.PROGRAM_NAME,
             b.EPISODE_NAME, b.NORM_KEY, b.EPISODES, b.BLOCK_START, b.BLOCK_END,
             b.BLOCK_START_MIN, b.BLOCK_AA, b.BLOCK_MIN
),
leadin_pick AS (
    -- [LEADIN-TC] the ONE telecast that ends within p_adjacent_min of the unit's
    -- start: the closest end wins, then the longest. Any programme, any airing.
    -- Under BLOCK the series' own first runs are excluded, as before [BLK2];
    -- under TELECAST they are not: a 10p premiere leads into a 10:30p one.
    SELECT b.NETWORK_CODE, b.BROADCAST_DATE, b.PROGRAM_CODE AS SERIES_CODE, b.UNIT_KEY,
           n.PROGRAM_CODE AS LEADIN_CODE, n.TELECAST_NUM AS LEADIN_TELECAST_NUM,
           n.START_MIN AS LEADIN_START_MIN
    FROM blk_adj b
    JOIN night n
      ON  n.NETWORK_CODE   = b.NETWORK_CODE
      AND n.BROADCAST_DATE = b.BROADCAST_DATE
      AND n.END_MIN <= b.ADJ_START_MIN
      AND b.ADJ_START_MIN - n.END_MIN <= COALESCE($p_adjacent_min, 0)
      AND ($p_min_leadin_min IS NULL OR n.CONTRIBUTING_DURATION >= $p_min_leadin_min)
      AND NOT (n.PROGRAM_CODE = b.PROGRAM_CODE AND n.TELECAST_NUM = b.UNIT_KEY)
      AND NOT ($p_leadin_grain = 'BLOCK' AND n.PROGRAM_CODE = b.PROGRAM_CODE AND n.IS_FIRST_RUN_CT)
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY b.NETWORK_CODE, b.BROADCAST_DATE, b.PROGRAM_CODE, b.UNIT_KEY
        ORDER BY n.END_MIN DESC, n.CONTRIBUTING_DURATION DESC, n.PROGRAM_CODE) = 1
),
leadin_seed AS (
    -- exactly the picked telecast, under both grains. (v72-v74 walked the
    -- lead-in programme's run backwards; that is what produced two Tom Hanks
    -- episodes for one Modern Marvels premiere, and it is gone.)
    SELECT p.NETWORK_CODE, p.BROADCAST_DATE, p.SERIES_CODE, p.UNIT_KEY,
           p.LEADIN_CODE, MAX(n.PROGRAM_NAME) AS LEADIN_PROGRAM,
           MAX(n.EPISODE_NAME) AS LEADIN_EPISODE,
           MIN(n.START_TIME) AS LEADIN_START, MAX(n.END_TIME) AS LEADIN_END,
           SUM(n.DEMO * n.CONTRIBUTING_DURATION)
             / NULLIF(SUM(n.CONTRIBUTING_DURATION), 0) AS LEADIN_AA,
           SUM(n.CONTRIBUTING_DURATION) AS LEADIN_MIN,
           COUNT(*) AS LEADIN_EPISODES,
           MAX(IFF(n.IS_FIRST_RUN_CT, 0, 1)) AS LEADIN_REPEAT
    FROM leadin_pick p
    JOIN night n
      ON  n.NETWORK_CODE   = p.NETWORK_CODE
      AND n.BROADCAST_DATE = p.BROADCAST_DATE
      AND n.PROGRAM_CODE   = p.LEADIN_CODE
      AND n.TELECAST_NUM   = p.LEADIN_TELECAST_NUM
    GROUP BY p.NETWORK_CODE, p.BROADCAST_DATE, p.SERIES_CODE, p.UNIT_KEY, p.LEADIN_CODE
)
SELECT
    REPLACE($demo_used, '_AA_ESTIMATES', '') AS DEMO_USED,
    b.NETWORK_CODE   AS NETWORK,
    b.BROADCAST_DATE AS AIR_DATE,
    b.PROGRAM_NAME   AS PROGRAM,
    b.EPISODE_NAME   AS EPISODE,
    b.NORM_KEY       AS SEASON,
    b.EPISODES, b.BLOCK_START, b.BLOCK_END, b.BLOCK_MIN,
    ROUND(b.BLOCK_AA/1000, 0)                              AS BLOCK_AA_000,
    l.LEADIN_PROGRAM,
    l.LEADIN_EPISODE,
    CASE WHEN l.LEADIN_PROGRAM IS NULL THEN 'NO LEAD-IN'
         WHEN l.LEADIN_REPEAT = 1      THEN 'REPEAT'
         ELSE 'PREMIERE' END                                    AS LEADIN_AIRING,
    l.LEADIN_START, l.LEADIN_END, l.LEADIN_EPISODES, l.LEADIN_MIN,
    ROUND(l.LEADIN_AA/1000, 0)                             AS LEADIN_AA_000,
    ROUND(ROUND(b.BLOCK_AA/1000,0)
          / NULLIF(ROUND(l.LEADIN_AA/1000,0),0), 4)        AS RETENTION,
    ROUND((ROUND(b.BLOCK_AA/1000,0)
           / NULLIF(ROUND(l.LEADIN_AA/1000,0),0) - 1) * 100, 1) AS PCT_VS_LEADIN,
    $win_from               AS FROM_DATE,
    $win_to                 AS TO_DATE
FROM blk b
LEFT JOIN leadin_seed l
  ON  l.NETWORK_CODE   = b.NETWORK_CODE
  AND l.BROADCAST_DATE = b.BROADCAST_DATE
  AND l.SERIES_CODE    = b.PROGRAM_CODE
  AND l.UNIT_KEY       = b.UNIT_KEY
WHERE NOT $p_rollup

UNION ALL
-- [LEADIN-ROLLUP] one ALL LEAD-INS row, then one row per lead-in programme AND
-- airing (Aya, 28 Sep 2026: "breakdown by actual lead-in program/type"), so a
-- premiere and a repeat of the same programme are two rows.
SELECT
    REPLACE($demo_used, '_AA_ESTIMATES', '') AS DEMO_USED,
    NETWORK_CODE   AS NETWORK,
    NULL           AS AIR_DATE,
    PROGRAM_NAME   AS PROGRAM,
    NULL           AS EPISODE,
    NORM_KEY       AS SEASON,
    SUM(EPISODES)  AS EPISODES,
    NULL AS BLOCK_START, NULL AS BLOCK_END,
    SUM(BLOCK_MIN) AS BLOCK_MIN,
    ROUND(SUM(BLOCK_AA * BLOCK_MIN) / NULLIF(SUM(BLOCK_MIN),0) / 1000, 0)        AS BLOCK_AA_000,
    COALESCE(LEADIN_PROGRAM, 'ALL LEAD-INS')                                       AS LEADIN_PROGRAM,
    NULL           AS LEADIN_EPISODE,
    COALESCE(LEADIN_AIRING, 'ALL')                                                 AS LEADIN_AIRING,
    NULL AS LEADIN_START, NULL AS LEADIN_END,
    SUM(LEADIN_EPISODES) AS LEADIN_EPISODES,
    SUM(LEADIN_MIN)      AS LEADIN_MIN,
    ROUND(SUM(LEADIN_AA * LEADIN_MIN) / NULLIF(SUM(LEADIN_MIN),0) / 1000, 0)     AS LEADIN_AA_000,
    ROUND(ROUND(SUM(BLOCK_AA * BLOCK_MIN) / NULLIF(SUM(BLOCK_MIN),0) / 1000, 0)
          / NULLIF(ROUND(SUM(LEADIN_AA * LEADIN_MIN) / NULLIF(SUM(LEADIN_MIN),0) / 1000, 0), 0), 4) AS RETENTION,
    ROUND((ROUND(SUM(BLOCK_AA * BLOCK_MIN) / NULLIF(SUM(BLOCK_MIN),0) / 1000, 0)
           / NULLIF(ROUND(SUM(LEADIN_AA * LEADIN_MIN) / NULLIF(SUM(LEADIN_MIN),0) / 1000, 0), 0) - 1) * 100, 1) AS PCT_VS_LEADIN,
    $win_from AS FROM_DATE,
    $win_to   AS TO_DATE
FROM (
    SELECT b.NETWORK_CODE, b.PROGRAM_NAME, b.NORM_KEY, b.EPISODES, b.BLOCK_MIN, b.BLOCK_AA,
           l.LEADIN_PROGRAM, IFF(l.LEADIN_REPEAT = 1, 'REPEAT', 'PREMIERE') AS LEADIN_AIRING,
           l.LEADIN_EPISODES, l.LEADIN_MIN, l.LEADIN_AA
    FROM blk b
    JOIN leadin_seed l
      ON  l.NETWORK_CODE   = b.NETWORK_CODE
      AND l.BROADCAST_DATE = b.BROADCAST_DATE
      AND l.SERIES_CODE    = b.PROGRAM_CODE
      AND l.UNIT_KEY       = b.UNIT_KEY
    WHERE $p_rollup
)
GROUP BY GROUPING SETS ((NETWORK_CODE, PROGRAM_NAME, NORM_KEY),
                        (NETWORK_CODE, PROGRAM_NAME, NORM_KEY, LEADIN_PROGRAM, LEADIN_AIRING))
ORDER BY AIR_DATE NULLS LAST, BLOCK_START, IFF(LEADIN_PROGRAM = 'ALL LEAD-INS', 0, 1), LEADIN_PROGRAM, LEADIN_AIRING;
