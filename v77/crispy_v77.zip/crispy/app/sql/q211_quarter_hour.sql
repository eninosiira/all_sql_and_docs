/* ============================================================================
   FILE       2.11 QUARTER-HOUR PERFORMANCE                         (PRD 2.11)
   PURPOSE    Each first-run telecast broken into its quarter hours, against the
              season norm for the same position.
   SOURCE     CRIS_QH_FACT, built in section 1 [S1-T2]
   RULES      [Q1] the short first QH is kept: an offset start such as :05 is
                   real programme time, not noise
              [Q2] only the trailing runover is dropped
              [Q3] the norm per position is LEAVE-ONE-OUT, so an episode never
                   norms against itself
              [Q4] delta from one QH to the next inside the episode
              [Q5] last against first QH per episode, and the same for the
                   norm: FINAL_VS_QH1_PCT / FINAL_VS_QH1_NORM_PCT, named as in
                   1.2. Jill, 28 Sep 2026: the comparison A&E want is how the
                   series moves through the telecast against how the norm
                   moves, not series AA against norm AA (VS_NORM_PCT stays as
                   a secondary column).
   [S1-2959]  Ordering is by the quarter hour's own start. v6 v1 ordered by the
              EPISODE start, identical on every QH row of that episode, so the
              position came out arbitrary: a 2-minute runover appeared
              mid-episode and the runover filter dropped a real 13-minute QH1.
   ============================================================================ */
-- ===== PARAMETERS =====
SET p_network       = 'HIST';
SET p_program       = '%SECRET SKINWALKER RANCH%';
SET p_stream        = 'Live+SD';
SET p_norm_basis    = 'SLOT';   -- [QH-NORM] 'SLOT' = per clock quarter hour, population per QH: reproduces
                                --          Jill's "QH - New" sheet (30 Sep 2026: 191/191/213/190,
                                --          234/239/244/228). Default, pending Tommy's word.
                                --          'SHAPE' = same start half hour and length, one population (v75)
                                --          'SEASON' = the series' other telecasts, leave-one-out
                                      -- A&E, 24 Sep 2026: the latest 12 months of
                                      -- the network's first-run premieres airing
                                      -- in the SAME time period as the programme,
                                      -- all days of the week, with NO specials,
                                      -- mini-series or Curse exclusions, because
                                      -- what matters here is the within-telecast
                                      -- build, not the audience level. 'SEASON'
                                      -- keeps the old norm: the same series'
                                      -- other telecasts, leave-one-out.
SET p_norm_months   = 12;
-- [QH-PREMNORM] Aya/Jill, 28 Sep 2026: the time-period norm is "the agreed
-- latest-12-month PREMIERE norm for programmes airing in the same time period",
-- so it takes the premiere norm's exclusions from 2.2 with the same defaults.
SET p_include_specials = FALSE;
SET p_movies        = 'EXCLUDE';  -- 'EXCLUDE' | 'ONLY' | 'BOTH'
SET p_exclude_curse = TRUE;       -- HIST only: Curse of Oak Island out of the norm
SET p_rollup        = FALSE;       -- [QH-ROLLUP] TRUE returns four rows for the
                                   -- season: QH1 to QH4 averaged across every
                                   -- telecast, duration weighted, plus QH4 vs
                                   -- QH1. Jill, 23 Sep 2026: "the average QH
                                   -- across all telecasts for the season". FALSE,
                                   -- the default, returns every telecast's
                                   -- quarter hours as before. The NORM column on
                                   -- the roll-up is the position norm this query
                                   -- already builds; Jill is confirming with the
                                   -- team what the norm should be based on.
SET p_demo      = 'DEMO_AA';
SET p_season        = NULL;
SET p_runover_max_min = 15;
SET p_win_to   = NULL;
SET data_sun = (SELECT LATEST_FULL_SUNDAY FROM AUDIENCE_DEV_DB.CRIS.CRIS_LATEST_DATE
                 WHERE NETWORK_CODE = $p_network AND RATING_SOURCE = $p_stream);
-- [CAP-SUN] the window can never run past the latest full Sunday with data, even when a
-- later date is passed in (A&E review, 27 Sep 2026: TO_DATE showed a date with no data yet).
SET win_to   = (SELECT LEAST(COALESCE(TO_DATE($p_win_to), $data_sun), $data_sun));


-- [DEMOUSED] resolve p_demo to a real column name and return it with the answer.
-- DEMO_AA is a real column carrying each network's own key demo, so a query runs
-- on it and never states what it measured. Read back, "DEMO_AA" tells a consumer
-- nothing: it is P25-64 on AEN, HIST and FYI, F25-64 on LIF and LMN, P18-49 on
-- VICE. SP_3 and SP_6 both failed on that - the question asked for P25+, the
-- default answered on P25-64, and 242 came back where 438 was expected. A wrong
-- demo does not look wrong, it looks like a number.
SET demo_used = (SELECT IFF(UPPER(COALESCE($p_demo,'DEMO_AA')) = 'DEMO_AA',
                     CASE $p_network
                          WHEN 'AEN'  THEN 'P25_64_AA_ESTIMATES'
                          WHEN 'HIST' THEN 'P25_64_AA_ESTIMATES'
                          WHEN 'FYI'  THEN 'P25_64_AA_ESTIMATES'
                          WHEN 'LIF'  THEN 'F25_64_AA_ESTIMATES'
                          WHEN 'LMN'  THEN 'F25_64_AA_ESTIMATES'
                          -- VICE is a SiiRA assumption, never confirmed by A&E
                          WHEN 'VICE' THEN 'P18_49_AA_ESTIMATES'
                          ELSE 'UNRESOLVED - no default demo outside the six'
                     END,
                     UPPER($p_demo)));

WITH base AS (
    SELECT f.NETWORK_CODE, f.PROGRAM_CODE, f.TELECAST_NUM,
           f.PROGRAM_NAME, f.EPISODE_NAME, f.CT_SEASON,
           f.BROADCAST_DATE, f.QTR_START_TIME, f.QH_START_2959, f.EP_START_2959,
           CAST(f.QH_MIN AS INT) AS QH_MIN,
           IDENTIFIER($p_demo) AS DEMO
    FROM AUDIENCE_DEV_DB.CRIS.CRIS_QH_FACT f
    WHERE f.NETWORK_CODE  = $p_network
      AND f.RATING_SOURCE = $p_stream
      AND f.IS_FIRST_RUN_CT
      AND f.PROGRAM_NAME ILIKE $p_program
      AND f.BROADCAST_DATE <= $win_to
      AND ($p_season IS NULL OR f.CT_SEASON = $p_season)
      AND f.CT_SEASON IS NOT NULL),
scoped AS (
    -- the season in scope: the most recent one unless pinned
    SELECT b.* FROM base b
    JOIN (SELECT PROGRAM_CODE, CT_SEASON
          FROM base
          QUALIFY ROW_NUMBER() OVER (PARTITION BY PROGRAM_CODE
                                     ORDER BY BROADCAST_DATE DESC) = 1) t
      ON t.PROGRAM_CODE = b.PROGRAM_CODE
     AND EQUAL_NULL(t.CT_SEASON, b.CT_SEASON)
),
seq AS (
    SELECT s.*,
        ROW_NUMBER() OVER (PARTITION BY PROGRAM_CODE, TELECAST_NUM
                           ORDER BY QH_START_2959)  AS QH_NUM,
        COUNT(*)     OVER (PARTITION BY PROGRAM_CODE, TELECAST_NUM) AS TOTAL_QH
    FROM scoped s
),
kept AS (
    -- [Q1] short QH1 kept, [Q2] trailing runover dropped
    SELECT * FROM seq
    WHERE NOT (QH_NUM = TOTAL_QH AND QH_NUM > 1 AND QH_MIN < $p_runover_max_min)
),
tp_norm AS (
    -- [QH-NORM] the time-period norm, position by position. Two readings of
    -- "premieres airing in the same time period", chosen by p_norm_basis:
    --
    --   SLOT  (Jill's pull, 29 Sep 2026): each of the series' clock quarter
    --         hours on its own. QH1 = 9:00-9:15p is normed against EVERY
    --         first-run quarter hour that aired 9:00-9:15p, whatever telecast
    --         it belongs to and wherever that telecast started: a 2-hour Alone
    --         that began at 8p, a Pawn Stars that began at 9:30. The population
    --         changes by quarter hour (191 / 191 / 213 / 190 on her sheet).
    --   SHAPE (v75): the telecasts that start in the same half hour and run the
    --         same number of quarter hours, followed through their own QH1-QH4.
    --         One fixed population (152).
    --
    -- Aya, 29 Sep 2026, traced the 152 vs 191 difference to exactly this.
    -- Jill: "we would need it to be the way I pulled it", pending Tommy.
    SELECT p.QH_NUM,
           SUM(n.DEMO * n.QH_MIN) / NULLIF(SUM(n.QH_MIN), 0) AS TP_NORM_AA,
           COUNT(DISTINCT n.PROGRAM_CODE || '|' || n.TELECAST_NUM || '|' || n.BROADCAST_DATE) AS TP_NORM_TC
    FROM (
        SELECT f.PROGRAM_CODE, f.TELECAST_NUM, f.BROADCAST_DATE, f.EP_START_2959, f.QH_START_2959,
               CAST(f.QH_MIN AS INT) AS QH_MIN, IDENTIFIER($p_demo) AS DEMO,
               ROW_NUMBER() OVER (PARTITION BY f.PROGRAM_CODE, f.TELECAST_NUM
                                  ORDER BY f.QH_START_2959) AS QH_NUM,
               COUNT(*) OVER (PARTITION BY f.PROGRAM_CODE, f.TELECAST_NUM) AS TOTAL_QH
        FROM AUDIENCE_DEV_DB.CRIS.CRIS_QH_FACT f
        WHERE f.NETWORK_CODE  = $p_network
          AND f.RATING_SOURCE = $p_stream
          AND f.IS_FIRST_RUN_CT
          AND f.BROADCAST_DATE BETWEEN DATEADD('day', 1, DATEADD('month', -$p_norm_months, $win_to))
                                   AND $win_to
          -- [QH-PREMNORM] premiere-norm exclusions, as in 2.2
          AND ($p_include_specials OR f.CONTENT_TYPE <> 'Special')
          AND ( $p_movies = 'BOTH'
             OR ($p_movies = 'EXCLUDE' AND f.MOVIE_IND = 0)
             OR ($p_movies = 'ONLY'    AND f.MOVIE_IND = 1) )
          AND NOT ($p_exclude_curse AND f.NETWORK_CODE = 'HIST'
                   AND UPPER(f.PROGRAM_NAME) LIKE '%CURSE%OAK ISLAND%')
    ) n
    JOIN (
        -- the series' own positions: the clock quarter hour each QH_NUM sits in
        -- (SLOT) and the shape of its telecasts (SHAPE)
        SELECT DISTINCT QH_NUM,
               IFF($p_norm_basis = 'SLOT', QH_START_2959, NULL) AS QH_START_2959,
               IFF($p_norm_basis = 'SLOT', NULL,
                   FLOOR(EP_START_2959 / 100) * 100 + IFF(MOD(EP_START_2959, 100) >= 30, 30, 0)) AS START_HH,
               IFF($p_norm_basis = 'SLOT', NULL, TOTAL_QH) AS TOTAL_QH
        FROM seq
    ) p
      ON ( $p_norm_basis = 'SLOT'
           -- clock quarter-hour bucket: 2132 and 2130 are the same 9:30-9:45 slot,
           -- because QH_START_2959 keeps a programme's real start inside the slot
           AND FLOOR(n.QH_START_2959 / 100) * 100 + FLOOR(MOD(n.QH_START_2959, 100) / 15) * 15
             = FLOOR(p.QH_START_2959 / 100) * 100 + FLOOR(MOD(p.QH_START_2959, 100) / 15) * 15 )
      OR ( $p_norm_basis <> 'SLOT'
           AND FLOOR(n.EP_START_2959 / 100) * 100 + IFF(MOD(n.EP_START_2959, 100) >= 30, 30, 0) = p.START_HH
           AND n.TOTAL_QH = p.TOTAL_QH
           AND n.QH_NUM   = p.QH_NUM )
    -- [Q2] the runover rule applies to the SERIES (kept), not to a SLOT norm:
    -- Jill's 9:30-9:45 population counts Mountain Men and Swamp People, 8p shows
    -- whose last 3-4 minutes fall in that slot (191 + 23 = 213 on her sheet).
    -- Every quarter hour that airs in the slot counts, weighted by its minutes.
    -- SHAPE keeps the rule so its telecasts line up position by position.
    WHERE $p_norm_basis = 'SLOT'
       OR NOT (n.QH_NUM = n.TOTAL_QH AND n.QH_NUM > 1 AND n.QH_MIN < $p_runover_max_min)
    GROUP BY p.QH_NUM
),
normed AS (
    SELECT k.*,
        t.TP_NORM_AA, t.TP_NORM_TC,
        -- [Q3] leave-one-out: subtract this episode from its own position norm
        -- [QH-WEIGHTED] duration weighted, as the Overnight Summary does it.
        -- A&E, 10 Sep 2026. A short quarter hour used to count the same as a
        -- full one, so a truncated QH1 pulled the position norm toward itself.
        IFF($p_norm_basis <> 'SEASON', t.TP_NORM_AA,
            (SUM(k.DEMO * k.QH_MIN) OVER (PARTITION BY k.PROGRAM_CODE, k.CT_SEASON, k.QH_NUM)
               - k.DEMO * k.QH_MIN)
              / NULLIF(SUM(k.QH_MIN) OVER (PARTITION BY k.PROGRAM_CODE, k.CT_SEASON, k.QH_NUM)
                       - k.QH_MIN, 0))                                 AS NORM_AA,
        IFF($p_norm_basis <> 'SEASON', t.TP_NORM_TC,
            COUNT(*) OVER (PARTITION BY k.PROGRAM_CODE, k.CT_SEASON, k.QH_NUM) - 1) AS NORM_TC,
        LAG(k.DEMO) OVER (PARTITION BY k.PROGRAM_CODE, k.TELECAST_NUM
                        ORDER BY k.QH_NUM)                             AS PREV_AA,
        FIRST_VALUE(k.DEMO) OVER (PARTITION BY k.PROGRAM_CODE, k.TELECAST_NUM
                        ORDER BY k.QH_NUM
                        ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) AS QH1_AA,
        LAST_VALUE(k.DEMO)  OVER (PARTITION BY k.PROGRAM_CODE, k.TELECAST_NUM
                        ORDER BY k.QH_NUM
                        ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) AS LAST_AA
    FROM kept k
    LEFT JOIN tp_norm t ON t.QH_NUM = k.QH_NUM
),
normed_mv AS (
    -- [QH-NORMMOVE] the norm's own movement, position to position, so the
    -- series' QH1 -> QH4 drift can be read against the norm's QH1 -> QH4 drift
    -- (A&E review 27 Sep 2026, template #15: "compare series movement vs norm").
    SELECT n.*,
        LAG(n.NORM_AA) OVER (PARTITION BY n.PROGRAM_CODE, n.TELECAST_NUM
                        ORDER BY n.QH_NUM)                              AS NORM_PREV_AA,
        FIRST_VALUE(n.NORM_AA) OVER (PARTITION BY n.PROGRAM_CODE, n.TELECAST_NUM
                        ORDER BY n.QH_NUM
                        ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) AS NORM_QH1_AA,
        LAST_VALUE(n.NORM_AA)  OVER (PARTITION BY n.PROGRAM_CODE, n.TELECAST_NUM
                        ORDER BY n.QH_NUM
                        ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) AS NORM_LAST_AA
    FROM normed n
),
season_qh AS (
    SELECT NETWORK_CODE, PROGRAM_NAME, CT_SEASON, QH_NUM,
           SUM(DEMO * QH_MIN)    / NULLIF(SUM(QH_MIN), 0)  AS QH_AA,
           SUM(NORM_AA * QH_MIN) / NULLIF(SUM(QH_MIN), 0)  AS QH_NORM,
           MAX(NORM_TC)                                    AS QH_NORM_TC,
           SUM(QH_MIN)                                     AS QH_MIN,
           COUNT(*)                                        AS TELECASTS
    FROM normed_mv
    WHERE $p_rollup
    GROUP BY NETWORK_CODE, PROGRAM_NAME, CT_SEASON, QH_NUM
),
rolled AS (
    SELECT s.*,
           LAG(QH_AA) OVER (PARTITION BY NETWORK_CODE, PROGRAM_NAME, CT_SEASON ORDER BY QH_NUM) AS PREV_AA,
           FIRST_VALUE(QH_AA) OVER (PARTITION BY NETWORK_CODE, PROGRAM_NAME, CT_SEASON ORDER BY QH_NUM)  AS QH1_AA,
           LAST_VALUE(QH_AA)  OVER (PARTITION BY NETWORK_CODE, PROGRAM_NAME, CT_SEASON ORDER BY QH_NUM
                                    ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) AS LAST_AA,
           LAG(QH_NORM) OVER (PARTITION BY NETWORK_CODE, PROGRAM_NAME, CT_SEASON ORDER BY QH_NUM) AS NORM_PREV_AA,
           FIRST_VALUE(QH_NORM) OVER (PARTITION BY NETWORK_CODE, PROGRAM_NAME, CT_SEASON ORDER BY QH_NUM) AS NORM_QH1_AA,
           LAST_VALUE(QH_NORM)  OVER (PARTITION BY NETWORK_CODE, PROGRAM_NAME, CT_SEASON ORDER BY QH_NUM
                                    ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) AS NORM_LAST_AA
    FROM season_qh s
)
SELECT
    REPLACE($demo_used, '_AA_ESTIMATES', '') AS DEMO_USED,   -- [DEMOUSED]
    NETWORK_CODE   AS NETWORK,
    BROADCAST_DATE AS AIR_DATE,
    PROGRAM_NAME   AS PROGRAM,
    EPISODE_NAME   AS EPISODE,
    CT_SEASON     AS SEASON,
    'QH' || QH_NUM AS QUARTER_HOUR,
    QTR_START_TIME AS QH_START,
    QH_MIN,
    ROUND(DEMO/1000, 0)                                            AS AA_000,
    -- [Q4]
    CASE WHEN PREV_AA IS NOT NULL
         THEN ROUND((ROUND(DEMO/1000,0)/NULLIF(ROUND(PREV_AA/1000,0),0)-1)*100, 1) END
                                                                   AS VS_PRIOR_QH_PCT,
    ROUND(NORM_AA/1000, 0)                                         AS NORM_AA_000,
    NORM_TC,
    ROUND((ROUND(DEMO/1000,0)/NULLIF(ROUND(NORM_AA/1000,0),0)-1)*100, 1) AS VS_NORM_PCT,
    -- [Q5]
    ROUND((ROUND(LAST_AA/1000,0)/NULLIF(ROUND(QH1_AA/1000,0),0)-1)*100, 1) AS FINAL_VS_QH1_PCT,
    -- [QH-NORMMOVE] the norm's own movement on the same two measures
    CASE WHEN NORM_PREV_AA IS NOT NULL
         THEN ROUND((ROUND(NORM_AA/1000,0)/NULLIF(ROUND(NORM_PREV_AA/1000,0),0)-1)*100, 1) END
                                                                   AS NORM_VS_PRIOR_QH_PCT,
    ROUND((ROUND(NORM_LAST_AA/1000,0)/NULLIF(ROUND(NORM_QH1_AA/1000,0),0)-1)*100, 1) AS FINAL_VS_QH1_NORM_PCT,
    $win_to                 AS TO_DATE
FROM normed_mv
WHERE NOT $p_rollup
UNION ALL
SELECT
    REPLACE($demo_used, '_AA_ESTIMATES', '') AS DEMO_USED,
    NETWORK_CODE   AS NETWORK,
    NULL           AS AIR_DATE,
    PROGRAM_NAME   AS PROGRAM,
    'SEASON AVERAGE ' || TELECASTS || ' TELECASTS' AS EPISODE,
    CT_SEASON      AS SEASON,
    'QH' || QH_NUM AS QUARTER_HOUR,
    NULL           AS QH_START,
    QH_MIN,
    ROUND(QH_AA/1000, 0)                                           AS AA_000,
    CASE WHEN PREV_AA IS NOT NULL
         THEN ROUND((ROUND(QH_AA/1000,0)/NULLIF(ROUND(PREV_AA/1000,0),0)-1)*100, 1) END
                                                                   AS VS_PRIOR_QH_PCT,
    ROUND(QH_NORM/1000, 0)                                         AS NORM_AA_000,
    QH_NORM_TC                                                     AS NORM_TC,
    ROUND((ROUND(QH_AA/1000,0)/NULLIF(ROUND(QH_NORM/1000,0),0)-1)*100, 1) AS VS_NORM_PCT,
    ROUND((ROUND(LAST_AA/1000,0)/NULLIF(ROUND(QH1_AA/1000,0),0)-1)*100, 1) AS FINAL_VS_QH1_PCT,
    CASE WHEN NORM_PREV_AA IS NOT NULL
         THEN ROUND((ROUND(QH_NORM/1000,0)/NULLIF(ROUND(NORM_PREV_AA/1000,0),0)-1)*100, 1) END
                                                                   AS NORM_VS_PRIOR_QH_PCT,
    ROUND((ROUND(NORM_LAST_AA/1000,0)/NULLIF(ROUND(NORM_QH1_AA/1000,0),0)-1)*100, 1) AS FINAL_VS_QH1_NORM_PCT,
    $win_to                 AS TO_DATE
FROM rolled
ORDER BY 3 NULLS LAST, 7;